# Multilingual Real‑Time Video Calling Platform

This repository contains a full‑stack application that enables real‑time video
calls with live captions, instant translation and optional voice dubbing. The
project is inspired by Zoom’s clean interface and implements many of the
recommendations from the provided whitepaper on building a multilingual video
calling platform【717560568491959†L160-L217】.  The system is split into a
Node.js/Express back end and a React/Next.js front end and uses MongoDB for
data persistence.  Real‑time communication, captions and translation are
facilitated via WebRTC, Socket.IO and the Google Translate and Text‑To‑Speech
APIs.

## Contents

* [Architecture](#architecture)
* [Folder Structure](#folder-structure)
* [Setup Instructions](#setup-instructions)
* [API Documentation](#api-documentation)
* [Database Schema](#database-schema)
* [WebSocket Events](#websocket-events)
* [Sample Data](#sample-data)
* [Testing](#testing)
* [Deployment Guide](#deployment-guide)

## Architecture

The system adheres to a text‑first, dub‑second architecture as recommended in
the PDF【717560568491959†L320-L409】.  Video and audio are transported via
WebRTC in the client.  A signalling layer powered by Socket.IO connects
peers.  The back end exposes REST endpoints for authentication and room
management and maintains room state in MongoDB.  A translation service wraps
Google’s machine translation API and returns translated text for captions.
When a translation is requested, the server synthesises speech via
`google-tts-api` and broadcasts it to all listeners in the room.  Captions
and translations are persisted for audit and later retrieval.  Role‑based
access control is implemented with JWTs and simple middleware.

## Folder Structure

The project is organised into `backend` and `frontend` directories:

```
multilingual-video-call/
├── backend/             # Express server source code
│   ├── controllers/     # Route handlers
│   ├── middleware/      # Auth and RBAC
│   ├── models/          # Mongoose schemas
│   ├── routes/          # API routes
│   ├── services/        # Translation and TTS helpers
│   ├── tests/           # Jest test cases
│   ├── index.js         # Server entry point
│   └── package.json     # Back end dependencies
├── frontend/            # Next.js application
│   ├── components/      # Reusable UI components
│   ├── contexts/        # React context providers
│   ├── hooks/           # Custom hooks (speech recognition)
│   ├── pages/           # Next.js pages (home, auth, dashboard, meeting)
│   ├── services/        # Axios instance for API calls
│   ├── styles/          # Tailwind CSS
│   ├── tailwind.config.js
│   ├── postcss.config.js
│   └── package.json     # Front end dependencies
├── README.md            # This file
└── ...
```

## Setup Instructions

### Prerequisites

* Node.js ≥ 18 and npm
* MongoDB (local instance or Atlas cluster)

### Back end

1. **Install dependencies**

   ```sh
   cd multilingual-video-call/backend
   npm install
   ```

2. **Configure environment variables**

   Create a `.env` file in `backend/` and set the following values:

   ```env
   MONGODB_URI=mongodb://localhost:27017/multilingual
   JWT_SECRET=your_jwt_secret
   PORT=4000
   ```

3. **Run the server**

   ```sh
   npm start
   ```

   The server listens on the port specified in `PORT` (default `4000`).

### Front end

1. **Install dependencies**

   ```sh
   cd multilingual-video-call/frontend
   npm install
   ```

2. **Configure environment variables**

   Create a `.env.local` file in `frontend/` and define:

   ```env
   NEXT_PUBLIC_API_URL=http://localhost:4000/api
   NEXT_PUBLIC_SOCKET_URL=http://localhost:4000
   ```

3. **Run the front end**

   ```sh
   npm run dev
   ```

   The Next.js application will start on `http://localhost:3000` by default.

## API Documentation

### Authentication

| Method | Endpoint          | Description                         | Payload                      |
|-------:|-------------------|-------------------------------------|------------------------------|
| `POST` | `/api/auth/register` | Register a new user                 | `{ name, email, password }` |
| `POST` | `/api/auth/login`    | Authenticate existing user          | `{ email, password }`       |
| `GET`  | `/api/auth/me`       | Get current user information        | Requires Bearer token        |

Successful authentication returns a JSON Web Token (JWT) and user details.  The
token must be included in the `Authorization: Bearer <token>` header for
subsequent requests.

### Rooms

| Method | Endpoint                     | Description                                  | Payload |
|-------:|------------------------------|----------------------------------------------|---------|
| `POST` | `/api/rooms/create`          | Create a new room (host‑only)                | `{ name, languages, enableCaptions, enableTranslation, enableDubbing }` |
| `GET`  | `/api/rooms`                 | List rooms owned by the authenticated user   | —       |
| `GET`  | `/api/rooms/:roomId`         | Retrieve metadata for a single room          | —       |

The `languages` field is an array of ISO language codes allowed in the room
(e.g. `['en','es','fr']`).  The boolean flags control which real‑time
translation features are enabled.

### Captions

| Method | Endpoint                       | Description                       |
|-------:|--------------------------------|-----------------------------------|
| `GET`  | `/api/captions/:roomId`        | Fetch all captions for a room     |

Captions include original and translated text along with speaker and
language metadata.  Captions are also broadcast live over Socket.IO.

## Database Schema

### User

| Field    | Type    | Description                      |
|---------:|--------:|----------------------------------|
| `name`   | String  | Display name                     |
| `email`  | String  | Unique email address             |
| `password` | String | Hashed password (bcrypt)         |
| `role`   | String  | `user` or `admin`                |
| `createdAt` | Date | Timestamp                        |

### Room

| Field              | Type      | Description                                  |
|-------------------:|----------:|----------------------------------------------|
| `name`             | String    | Human‑readable room name                     |
| `host`             | ObjectId  | Reference to `User` who created the room     |
| `languages`        | [String]  | Allowed languages for the room               |
| `enableCaptions`   | Boolean   | Whether live captions are permitted          |
| `enableTranslation` | Boolean  | Whether translation is permitted             |
| `enableDubbing`    | Boolean   | Whether voice dubbing is permitted           |
| `createdAt`        | Date      | Timestamp                                    |

### Caption

| Field             | Type      | Description                                      |
|------------------:|----------:|--------------------------------------------------|
| `room`            | ObjectId  | Reference to `Room`                               |
| `user`            | ObjectId  | Reference to `User` (speaker)                    |
| `text`            | String    | Original caption text                            |
| `translatedText`  | String    | Translated text (if translation requested)       |
| `sourceLang`      | String    | ISO code of the spoken language                  |
| `targetLang`      | String    | ISO code of the translation language             |
| `final`           | Boolean   | Whether the caption corresponds to a final utterance |
| `createdAt`       | Date      | Timestamp                                        |

## WebSocket Events

The client and server communicate over Socket.IO for real‑time features:

### Client → Server

| Event        | Payload | Description |
|-------------:|--------:|-------------|
| `join-room`  | `{ roomId, userId, language }` | Join a room and register for calls and captions |
| `caption`    | `{ roomId, text, sourceLang, targetLang, final, userId }` | Send spoken text for translation |
| `call-user`  | `{ userToCall, signal, from }` | Forward WebRTC signalling data to another user |
| `answer-call` | `{ to, signal }` | Complete WebRTC handshake by returning signal data |

### Server → Client

| Event         | Payload | Description |
|--------------:|--------:|-------------|
| `user-joined` | `{ userId, socketId }` | A new participant joined the room |
| `call-made`   | `{ signal, from }` | Signal data received from a peer (to answer) |
| `call-accepted`| `{ signal, from }` | Confirmation signal from peer |
| `caption`     | `{ userId, text, translatedText, sourceLang, targetLang, final }` | New caption and translation |
| `audio`       | `{ userId, lang, url, text }` | URL to synthesized translated speech |
| `user-left`   | `{ userId, socketId }` | A participant disconnected |

## Sample Data

The front end includes a static list of common languages for demonstration
purposes.  You can extend this list or fetch supported languages from
translation providers.  The list includes English (`en`), Spanish (`es`),
French (`fr`), German (`de`), Hindi (`hi`), Chinese (Simplified, `zh-CN`),
Japanese (`ja`), Russian (`ru`), Portuguese (`pt`) and Arabic (`ar`).

## Testing

Jest and Supertest are used for automated testing of the back end.  An
example test in `backend/tests/auth.test.js` registers and logs in a user.
Run the test suite with:

```sh
cd multilingual-video-call/backend
npm test
```

The test will spin up the Express app, interact with the API, and then clean
up the database connection.  Additional tests can be added for rooms,
captions and WebSocket behaviour.

## Deployment Guide

### Back end (Render)

1. Push the contents of the `backend/` folder to a new repository on GitHub.
2. Create a new Web Service on [Render](https://render.com/) and link it to
   your repository.
3. Set the build command to `npm install` and the start command to `npm start`.
4. In the Render dashboard, add environment variables for `MONGODB_URI`,
   `JWT_SECRET` and `PORT`.  Ensure that `PORT` matches the internal port
   expected by Render (usually `10000` is automatically assigned, but you can
   hardcode `4000` if you expose the port explicitly).
5. Deploy the service.  Render will provide you with a public URL such as
   `https://your-backend.onrender.com`.  All API routes are prefixed with `/api`.

### Database (MongoDB Atlas)

1. Sign up for a free tier on [MongoDB Atlas](https://www.mongodb.com/cloud/atlas).
2. Create a new cluster and database.  Add a collection for users, rooms and
   captions (these will be created automatically on first use).
3. Whitelist your Render IP or set network access to open (not recommended for
   production).  Generate a connection string and set it as `MONGODB_URI` on
   Render.

### Front end (Vercel)

1. Push the contents of the `frontend/` folder to another GitHub repository.
2. Create a new project on [Vercel](https://vercel.com/) and import the
   repository.
3. Set the environment variables `NEXT_PUBLIC_API_URL` to the URL of your
   Render back end with `/api` appended (e.g.
   `https://your-backend.onrender.com/api`) and `NEXT_PUBLIC_SOCKET_URL` to
   the base Socket.IO URL (e.g. `https://your-backend.onrender.com`).
4. Deploy.  Vercel will build the Next.js app and serve it from a global CDN.

After deployment, visiting the Vercel URL will show the home page.  Users can
register, log in, create rooms, join calls, see captions and hear translated
audio.

---

This project implements all the primary features described in the PDF, such
as separate caption and translation planes, participant‑level language
selection, real‑time translation, optional dubbing and role‑based controls【717560568491959†L160-L217】.  Additional
features—such as fine‑grained consent, glossaries, advanced security modes
and multi‑region deployment—can be added by following the guidelines in the
whitepaper【717560568491959†L320-L409】.