const translate = require('@vitalets/google-translate-api');

/**
 * Translate text from a source language to a target language using the
 * Google Translate API wrapper. If no target language is provided or the
 * languages are the same, the original text is returned.
 *
 * @param {string} text - The text to translate.
 * @param {string} from - Source language code (e.g. 'en').
 * @param {string} to - Target language code (e.g. 'es').
 * @returns {Promise<{text: string}>} The translated result.
 */
async function translateText(text, from, to) {
  // Early exit when translation is unnecessary
  if (!to || to === from) {
    return { text };
  }
  try {
    const result = await translate(text, { from, to });
    return { text: result.text };
  } catch (err) {
    // In case of error, return the original text and log the error
    console.error('Translation error:', err.message);
    return { text };
  }
}

module.exports = { translateText };