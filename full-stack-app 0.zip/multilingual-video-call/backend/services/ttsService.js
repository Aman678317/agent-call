const googleTTS = require('google-tts-api');

/**
 * Generate a public Google Translate TTS URL for the given text and language.
 * The URL returned can be used to play back the speech in a browser. Note
 * that google-tts-api generates a URL to the audio file on translate.google.com.
 *
 * @param {string} text - The translated text to synthesize.
 * @param {string} lang - The target language code.
 * @returns {Promise<string>} A URL pointing to the synthesized audio.
 */
async function getAudioUrl(text, lang) {
  try {
    const url = googleTTS.getAudioUrl(text, {
      lang,
      slow: false,
      host: 'https://translate.google.com',
    });
    return url;
  } catch (err) {
    console.error('TTS generation error:', err.message);
    throw err;
  }
}

module.exports = { getAudioUrl };