const Room = require('../models/room');

/**
 * Create a new meeting room. Requires authentication. The request body may
 * include a name, a list of allowed languages, and booleans to enable
 * captions, translation, and dubbing. The authenticated user becomes the
 * host of the room.
 */
const createRoom = async (req, res) => {
  try {
    const { name, languages, enableCaptions, enableTranslation, enableDubbing } = req.body;
    if (!name) {
      return res.status(400).json({ message: 'Room name is required' });
    }
    const room = await Room.create({
      name,
      host: req.user.id,
      languages: languages || [],
      enableCaptions: enableCaptions !== undefined ? enableCaptions : true,
      enableTranslation: enableTranslation !== undefined ? enableTranslation : true,
      enableDubbing: enableDubbing || false,
    });
    res.status(201).json({ room });
  } catch (err) {
    console.error('Create room error:', err.message);
    res.status(500).json({ message: 'Server error' });
  }
};

/**
 * Retrieve a room by its ID. Returns the room document including its
 * configuration. This endpoint does not expose participant data since
 * participants are tracked via the real‑time socket layer.
 */
const getRoom = async (req, res) => {
  try {
    const { roomId } = req.params;
    const room = await Room.findById(roomId).lean();
    if (!room) return res.status(404).json({ message: 'Room not found' });
    res.json({ room });
  } catch (err) {
    console.error('Get room error:', err.message);
    res.status(500).json({ message: 'Server error' });
  }
};

/**
 * List all rooms owned by the authenticated user. Useful for a host
 * dashboard.
 */
const listRooms = async (req, res) => {
  try {
    const rooms = await Room.find({ host: req.user.id }).lean();
    res.json({ rooms });
  } catch (err) {
    console.error('List rooms error:', err.message);
    res.status(500).json({ message: 'Server error' });
  }
};

module.exports = { createRoom, getRoom, listRooms };