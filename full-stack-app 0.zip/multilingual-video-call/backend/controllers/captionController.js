const Caption = require('../models/caption');

/**
 * Retrieve all captions for a given room. Requires authentication. Returns
 * an array of caption documents including original and translated text.
 */
const getCaptions = async (req, res) => {
  try {
    const { roomId } = req.params;
    const captions = await Caption.find({ room: roomId }).populate('user', 'name email').lean();
    res.json({ captions });
  } catch (err) {
    console.error('Get captions error:', err.message);
    res.status(500).json({ message: 'Server error' });
  }
};

module.exports = { getCaptions };