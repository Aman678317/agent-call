const jwt = require('jsonwebtoken');

/**
 * Express middleware to verify a JWT. Expects the token in the Authorization
 * header in the form `Bearer <token>`. If valid, attaches the decoded token
 * payload to `req.user`.
 */
const verifyToken = (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Authorization token missing' });
  }
  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'secret');
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(403).json({ message: 'Invalid or expired token' });
  }
};

/**
 * Middleware factory to enforce role-based access control. Pass an array of
 * allowed roles; if the authenticated user's role is not in the list, the
 * request is rejected with a 403.
 */
const requireRole = (...roles) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ message: 'Not authenticated' });
    }
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ message: 'Forbidden' });
    }
    next();
  };
};

module.exports = { verifyToken, requireRole };