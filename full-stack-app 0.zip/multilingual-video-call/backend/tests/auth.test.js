const request = require('supertest');
const mongoose = require('mongoose');
const { app, server } = require('../index');
const User = require('../models/user');

// Clear users collection before each test
beforeEach(async () => {
  await User.deleteMany({});
});

afterAll(async () => {
  await User.deleteMany({});
  await mongoose.connection.close();
  server.close();
});

describe('Auth API', () => {
  test('should register and login a user', async () => {
    const userData = {
      name: 'Test User',
      email: 'test@example.com',
      password: 'password123',
    };
    // Register
    const registerRes = await request(app).post('/api/auth/register').send(userData);
    expect(registerRes.statusCode).toBe(200);
    expect(registerRes.body).toHaveProperty('token');
    expect(registerRes.body.user.email).toBe(userData.email);
    // Login
    const loginRes = await request(app).post('/api/auth/login').send({
      email: userData.email,
      password: userData.password,
    });
    expect(loginRes.statusCode).toBe(200);
    expect(loginRes.body).toHaveProperty('token');
    expect(loginRes.body.user.email).toBe(userData.email);
  });
});