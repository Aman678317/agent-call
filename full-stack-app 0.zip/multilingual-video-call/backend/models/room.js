const mongoose = require('mongoose');

const roomSchema = new mongoose.Schema({
  name: { type: String, required: true },
  host: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  languages: [{ type: String }],
  enableCaptions: { type: Boolean, default: true },
  enableTranslation: { type: Boolean, default: true },
  enableDubbing: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model('Room', roomSchema);