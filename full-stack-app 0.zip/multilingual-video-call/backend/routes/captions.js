const express = require('express');
const router = express.Router();
const captionController = require('../controllers/captionController');
const { verifyToken } = require('../middleware/auth');

// Fetch captions for a room
router.get('/:roomId', verifyToken, captionController.getCaptions);

module.exports = router;