const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const { verifyToken } = require('../middleware/auth');

// Register new user
router.post('/register', authController.register);
// Login existing user
router.post('/login', authController.login);
// Get current user info
router.get('/me', verifyToken, authController.me);

module.exports = router;