const express = require('express');
const router = express.Router();
const roomController = require('../controllers/roomController');
const { verifyToken } = require('../middleware/auth');

// Create a new room
router.post('/create', verifyToken, roomController.createRoom);
// List rooms owned by the authenticated user
router.get('/', verifyToken, roomController.listRooms);
// Get a specific room by ID
router.get('/:roomId', verifyToken, roomController.getRoom);

module.exports = router;