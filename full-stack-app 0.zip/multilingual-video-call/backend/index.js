const express = require('express');
const http = require('http');
const cors = require('cors');
const mongoose = require('mongoose');
const socketIo = require('socket.io');
const dotenv = require('dotenv');

// Load environment variables from .env if present
dotenv.config();

const authRoutes = require('./routes/auth');
const roomRoutes = require('./routes/rooms');
const captionRoutes = require('./routes/captions');
const { verifyToken } = require('./middleware/auth');
const TranslationService = require('./services/translationService');
const TTSService = require('./services/ttsService');
const Caption = require('./models/caption');

const app = express();
const server = http.createServer(app);

// Create Socket.IO server
const io = socketIo(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST'],
  },
});

// In-memory map from userId to socketId used for WebRTC signalling
const users = {};

// Middleware
app.use(cors());
app.use(express.json());

// Database connection
const mongoUri = process.env.MONGODB_URI || 'mongodb://localhost:27017/multilingual';
mongoose
  .connect(mongoUri, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log('MongoDB connected'))
  .catch((err) => console.error('MongoDB connection error:', err.message));

// API routes
app.use('/api/auth', authRoutes);
app.use('/api/rooms', roomRoutes);
app.use('/api/captions', captionRoutes);

// Simple health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok' });
});

/**
 * Socket.IO event handling.
 *
 * When a client connects they emit a `join-room` event with a payload
 * containing the room ID, their user ID, and their selected caption language.
 * The server joins the socket to that room and notifies other participants
 * that a new user has joined.
 *
 * Clients can emit `caption` events with their spoken text. The server
 * translates the text using the translation service and emits the result
 * back to all clients in the room. If a different language is requested
 * a text‑to‑speech URL is generated so clients can play the translated audio.
 */
io.on('connection', (socket) => {
  console.log('Socket connected:', socket.id);

  // Join a specific room
  socket.on('join-room', ({ roomId, userId, language }) => {
    socket.join(roomId);
    socket.roomId = roomId;
    socket.userId = userId;
    socket.language = language || null;
    // Map user ID to socket ID for signalling
    users[userId] = socket.id;
    // Notify other peers that a new user has joined
    socket.to(roomId).emit('user-joined', { userId, socketId: socket.id });
    console.log(`User ${userId} joined room ${roomId}`);
  });

  // WebRTC signalling: forward call signals to target users
  socket.on('call-user', ({ userToCall, signal, from }) => {
    const targetSocketId = users[userToCall];
    if (targetSocketId) {
      io.to(targetSocketId).emit('call-made', { signal, from });
    }
  });
  socket.on('answer-call', ({ to, signal }) => {
    const targetSocketId = users[to];
    if (targetSocketId) {
      io.to(targetSocketId).emit('call-accepted', { signal, from: socket.userId });
    }
  });

  // Receive caption text from client and broadcast translation
  socket.on('caption', async ({ roomId, text, sourceLang, targetLang, final, userId }) => {
    if (!text || text.trim() === '') return;
    try {
      // Translate the text if needed
      let translatedText = text;
      if (targetLang && targetLang !== sourceLang) {
        const result = await TranslationService.translateText(text, sourceLang, targetLang);
        translatedText = result.text;
      }
      // Persist caption in database
      const caption = new Caption({
        room: roomId,
        user: userId,
        text,
        translatedText,
        sourceLang,
        targetLang,
        final: final || false,
      });
      await caption.save();
      // Broadcast caption and translation to all clients in the room
      io.to(roomId).emit('caption', {
        userId,
        text,
        sourceLang,
        targetLang,
        translatedText,
        final: final || false,
      });
      // If translation language differs from source and dubbing is enabled for client, generate audio
      if (targetLang && targetLang !== sourceLang) {
        try {
          const audioUrl = await TTSService.getAudioUrl(translatedText, targetLang);
          io.to(roomId).emit('audio', {
            userId,
            lang: targetLang,
            url: audioUrl,
            text: translatedText,
          });
        } catch (ttsErr) {
          console.error('TTS generation failed:', ttsErr.message);
        }
      }
    } catch (err) {
      console.error('Error handling caption event:', err.message);
    }
  });

  socket.on('disconnect', () => {
    console.log('Socket disconnected:', socket.id);
    const { roomId, userId } = socket;
    if (roomId) {
      socket.to(roomId).emit('user-left', { userId, socketId: socket.id });
    }
    // Remove mapping for signalling
    if (userId && users[userId]) {
      delete users[userId];
    }
  });
});

// Start server
const PORT = process.env.PORT || 4000;
server.listen(PORT, () => {
  console.log(`Backend server listening on port ${PORT}`);
});

// Export app and server for testing
module.exports = { app, server };