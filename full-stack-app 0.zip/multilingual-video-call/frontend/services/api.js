import axios from 'axios';

// Base URL is configurable via environment variable. When deployed to Vercel,
// you can set NEXT_PUBLIC_API_URL to point at your Render backend URL.
const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/api',
});

export default api;