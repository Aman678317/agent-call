import { useContext, useState, useEffect } from 'react';
import Layout from '../components/Layout';
import { AuthContext } from '../contexts/AuthContext';

export default function Settings() {
  const { user } = useContext(AuthContext);
  const [defaultSourceLang, setDefaultSourceLang] = useState('en');
  const [defaultTargetLang, setDefaultTargetLang] = useState('');

  useEffect(() => {
    // Load stored preferences if present
    if (typeof window !== 'undefined') {
      const storedSource = localStorage.getItem('defaultSourceLang');
      const storedTarget = localStorage.getItem('defaultTargetLang');
      if (storedSource) setDefaultSourceLang(storedSource);
      if (storedTarget) setDefaultTargetLang(storedTarget);
    }
  }, []);

  const handleSave = (e) => {
    e.preventDefault();
    if (typeof window !== 'undefined') {
      localStorage.setItem('defaultSourceLang', defaultSourceLang);
      localStorage.setItem('defaultTargetLang', defaultTargetLang);
      alert('Preferences saved');
    }
  };

  return (
    <Layout>
      <div className="max-w-md mx-auto">
        <h2 className="text-2xl font-bold mb-4">Settings</h2>
        {!user && <p>Please log in to modify your settings.</p>}
        {user && (
          <form onSubmit={handleSave} className="space-y-4 bg-white p-4 border rounded">
            <div>
              <label className="block mb-1">Default Source Language</label>
              <input
                type="text"
                value={defaultSourceLang}
                onChange={(e) => setDefaultSourceLang(e.target.value)}
                className="w-full border rounded px-3 py-2"
              />
            </div>
            <div>
              <label className="block mb-1">Default Target Language (empty for none)</label>
              <input
                type="text"
                value={defaultTargetLang}
                onChange={(e) => setDefaultTargetLang(e.target.value)}
                className="w-full border rounded px-3 py-2"
              />
            </div>
            <button
              type="submit"
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded"
            >
              Save
            </button>
          </form>
        )}
      </div>
    </Layout>
  );
}