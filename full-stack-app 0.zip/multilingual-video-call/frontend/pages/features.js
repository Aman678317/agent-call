import Layout from '../components/Layout';

export default function Features() {
  return (
    <Layout>
      <div className="max-w-3xl mx-auto space-y-6">
        <h1 className="text-3xl font-bold mb-4">Platform Features</h1>
        <section>
          <h2 className="text-xl font-semibold mb-2">High‑Quality Video Conferencing</h2>
          <p className="text-gray-700">
            Our platform uses WebRTC to deliver crisp and low‑latency video and
            audio between participants. Create rooms, invite guests and enjoy
            uninterrupted calls across devices.
          </p>
        </section>
        <section>
          <h2 className="text-xl font-semibold mb-2">Live Captions &amp; Subtitles</h2>
          <p className="text-gray-700">
            Enable live captions to convert speech into on‑screen text in real
            time. Captions make your conversations more accessible and easier to
            follow, especially in noisy environments or for participants with
            hearing impairments.
          </p>
        </section>
        <section>
          <h2 className="text-xl font-semibold mb-2">Instant Translation</h2>
          <p className="text-gray-700">
            Participants can choose a preferred target language and the system
            will translate spoken words on the fly. Powered by state‑of‑the‑art
            machine translation, you can communicate seamlessly with people who
            speak different languages.
          </p>
        </section>
        <section>
          <h2 className="text-xl font-semibold mb-2">Voice Dubbing</h2>
          <p className="text-gray-700">
            In addition to subtitles, the platform can optionally synthesize
            translated audio using neural text‑to‑speech. Listen to translated
            speech in your language without muting the original speaker. Voice
            dubbing respects your privacy and only runs when enabled.
          </p>
        </section>
        <section>
          <h2 className="text-xl font-semibold mb-2">Customisable Permissions</h2>
          <p className="text-gray-700">
            Room hosts control which features are enabled—captions, translation
            and dubbing—and participants can personalise their own language
            preferences. Advanced security modes let administrators disable
            server‑side processing entirely for end‑to‑end encrypted calls.
          </p>
        </section>
      </div>
    </Layout>
  );
}