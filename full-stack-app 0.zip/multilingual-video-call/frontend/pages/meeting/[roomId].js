import { useRouter } from 'next/router';
import { useContext, useEffect, useRef, useState } from 'react';
import Layout from '../../components/Layout';
import { AuthContext } from '../../contexts/AuthContext';
import api from '../../services/api';
import io from 'socket.io-client';
import SimplePeer from 'simple-peer';
import useSpeechRecognition from '../../hooks/useSpeechRecognition';

// Define a static list of languages for demonstration purposes. In a
// production system you might fetch supported languages from the server.
const LANGUAGE_OPTIONS = [
  { code: 'en', name: 'English' },
  { code: 'es', name: 'Spanish' },
  { code: 'fr', name: 'French' },
  { code: 'de', name: 'German' },
  { code: 'hi', name: 'Hindi' },
  { code: 'zh-CN', name: 'Chinese (Simplified)' },
  { code: 'ja', name: 'Japanese' },
  { code: 'ru', name: 'Russian' },
  { code: 'pt', name: 'Portuguese' },
  { code: 'ar', name: 'Arabic' },
];

export default function MeetingPage() {
  const router = useRouter();
  const { roomId } = router.query;
  const { user, loading } = useContext(AuthContext);
  const [room, setRoom] = useState(null);
  const [sourceLang, setSourceLang] = useState('en');
  const [targetLang, setTargetLang] = useState('es');
  const [captions, setCaptions] = useState([]);
  const [streams, setStreams] = useState({});
  const [capturing, setCapturing] = useState(false);

  const socketRef = useRef(null);
  const peersRef = useRef({});
  const myVideoRef = useRef(null);
  const [myStream, setMyStream] = useState(null);

  // Speech recognition hook
  const { start: startListening, stop: stopListening } = useSpeechRecognition({
    lang: sourceLang,
    onResult: ({ text, final }) => {
      // Only send if capturing and we have non-empty text
      if (capturing && socketRef.current && text.trim() !== '') {
        socketRef.current.emit('caption', {
          roomId,
          text: text.trim(),
          sourceLang,
          targetLang,
          final,
          userId: user.id,
        });
      }
    },
  });

  useEffect(() => {
    if (!roomId || !user) return;
    // Fetch room details
    const fetchRoom = async () => {
      try {
        const res = await api.get(`/rooms/${roomId}`);
        setRoom(res.data.room);
      } catch (err) {
        console.error(err);
      }
    };
    fetchRoom();
  }, [roomId, user]);

  useEffect(() => {
    if (!roomId || !user) return;
    // Connect to socket and set up handlers
    const socketUrl = process.env.NEXT_PUBLIC_SOCKET_URL || 'http://localhost:4000';
    const socket = io(socketUrl, {
      transports: ['websocket'],
    });
    socketRef.current = socket;

    // Acquire media and join room
    navigator.mediaDevices
      .getUserMedia({ video: true, audio: true })
      .then((stream) => {
        setMyStream(stream);
        if (myVideoRef.current) {
          myVideoRef.current.srcObject = stream;
        }
        // Emit join-room event
        socket.emit('join-room', {
          roomId,
          userId: user.id,
          language: sourceLang,
        });
      })
      .catch((err) => {
        console.error('Error getting user media:', err);
      });

    // Listen for new users joining
    socket.on('user-joined', ({ userId, socketId }) => {
      // Initiate call to the new user
      callUser(userId);
    });

    // Handle incoming call
    socket.on('call-made', ({ signal, from }) => {
      // Answer the call
      const peer = new SimplePeer({
        initiator: false,
        trickle: false,
        stream: myStream,
      });
      peer.on('signal', (data) => {
        socket.emit('answer-call', { to: from, signal: data });
      });
      peer.on('stream', (remoteStream) => {
        addRemoteStream(from, remoteStream);
      });
      peer.signal(signal);
      peersRef.current[from] = peer;
    });

    // Handle call accepted
    socket.on('call-accepted', ({ signal, from }) => {
      const peer = peersRef.current[from];
      if (peer) {
        peer.signal(signal);
      }
    });

    // Caption received from server
    socket.on('caption', (data) => {
      setCaptions((prev) => [...prev, data]);
    });

    // Translated audio event
    socket.on('audio', ({ url, userId: speakerId }) => {
      // Play audio only if the translation is for another user
      if (speakerId !== user.id) {
        const audio = new Audio(url);
        audio.play().catch((e) => console.warn('Audio playback failed:', e));
      }
    });

    // User left event
    socket.on('user-left', ({ userId: leftUserId }) => {
      removeRemoteStream(leftUserId);
    });

    // Cleanup on unmount
    return () => {
      socket.disconnect();
      Object.values(peersRef.current).forEach((peer) => peer.destroy());
      if (myStream) {
        myStream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [roomId, user, myStream, sourceLang]);

  // Function to call another user via WebRTC
  const callUser = (userToCall) => {
    const socket = socketRef.current;
    if (!myStream || !socket) return;
    const peer = new SimplePeer({
      initiator: true,
      trickle: false,
      stream: myStream,
    });
    peer.on('signal', (data) => {
      socket.emit('call-user', { userToCall, signal: data, from: user.id });
    });
    peer.on('stream', (remoteStream) => {
      addRemoteStream(userToCall, remoteStream);
    });
    peersRef.current[userToCall] = peer;
  };

  // Helper to add remote stream
  const addRemoteStream = (remoteUserId, stream) => {
    setStreams((prev) => ({ ...prev, [remoteUserId]: stream }));
  };

  // Helper to remove remote stream
  const removeRemoteStream = (remoteUserId) => {
    setStreams((prev) => {
      const newStreams = { ...prev };
      delete newStreams[remoteUserId];
      return newStreams;
    });
    const peer = peersRef.current[remoteUserId];
    if (peer) {
      peer.destroy();
      delete peersRef.current[remoteUserId];
    }
  };

  const toggleCapturing = () => {
    if (!capturing) {
      startListening();
    } else {
      stopListening();
    }
    setCapturing(!capturing);
  };

  // Render video elements
  const renderRemoteVideos = () => {
    return Object.entries(streams).map(([uid, stream]) => (
      <video
        key={uid}
        className="w-40 h-32 bg-black rounded"
        playsInline
        autoPlay
        ref={(video) => {
          if (video) video.srcObject = stream;
        }}
      />
    ));
  };

  if (loading) return <Layout>Loading…</Layout>;
  if (!user) return null;

  return (
    <Layout>
      <div className="grid md:grid-cols-4 gap-4">
        <div className="md:col-span-3 bg-black rounded flex flex-wrap justify-center items-center p-2">
          {/* Local video */}
          <video
            ref={myVideoRef}
            className="w-40 h-32 bg-black rounded mr-2"
            autoPlay
            muted
            playsInline
          />
          {/* Remote videos */}
          {renderRemoteVideos()}
        </div>
        <div className="md:col-span-1 bg-white rounded p-4 flex flex-col">
          <h2 className="text-lg font-semibold mb-2">Controls</h2>
          <div className="mb-3">
            <label className="block mb-1">Your Language</label>
            <select
              value={sourceLang}
              onChange={(e) => setSourceLang(e.target.value)}
              className="w-full border rounded px-2 py-1"
            >
              {LANGUAGE_OPTIONS.map((opt) => (
                <option key={opt.code} value={opt.code}>
                  {opt.name}
                </option>
              ))}
            </select>
          </div>
          <div className="mb-3">
            <label className="block mb-1">Translation Language</label>
            <select
              value={targetLang}
              onChange={(e) => setTargetLang(e.target.value)}
              className="w-full border rounded px-2 py-1"
            >
              <option value="">None</option>
              {LANGUAGE_OPTIONS.map((opt) => (
                <option key={opt.code} value={opt.code}>
                  {opt.name}
                </option>
              ))}
            </select>
          </div>
          <button
            onClick={toggleCapturing}
            className={`mb-4 px-4 py-2 rounded text-white ${
              capturing ? 'bg-red-600 hover:bg-red-700' : 'bg-green-600 hover:bg-green-700'
            }`}
          >
            {capturing ? 'Stop Captions' : 'Start Captions'}
          </button>
          <div className="flex-1 overflow-y-auto border rounded p-2">
            <h3 className="font-semibold mb-2">Captions</h3>
            {captions.map((cap, idx) => (
              <div key={idx} className="mb-2 text-sm">
                <span className="font-bold mr-1">{cap.userId === user.id ? 'You' : cap.userId}:</span>
                <span className="text-gray-800">{cap.text}</span>
                {cap.translatedText && cap.targetLang && (
                  <span className="text-blue-700 ml-2">({cap.translatedText})</span>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </Layout>
  );
}