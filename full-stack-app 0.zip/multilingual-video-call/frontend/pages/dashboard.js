import { useContext, useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import Layout from '../components/Layout';
import api from '../services/api';
import { AuthContext } from '../contexts/AuthContext';

export default function Dashboard() {
  const router = useRouter();
  const { user, loading } = useContext(AuthContext);
  const [rooms, setRooms] = useState([]);
  const [name, setName] = useState('');
  const [languages, setLanguages] = useState('');
  const [enableCaptions, setEnableCaptions] = useState(true);
  const [enableTranslation, setEnableTranslation] = useState(true);
  const [enableDubbing, setEnableDubbing] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!loading && !user) {
      // Redirect unauthenticated users to login
      router.push('/login');
    }
    if (!loading && user) {
      fetchRooms();
    }
  }, [loading, user]);

  const fetchRooms = async () => {
    try {
      const res = await api.get('/rooms');
      setRooms(res.data.rooms);
    } catch (err) {
      console.error(err);
    }
  };

  const handleCreate = async (e) => {
    e.preventDefault();
    setError(null);
    try {
      const res = await api.post('/rooms/create', {
        name,
        languages: languages
          .split(',')
          .map((l) => l.trim())
          .filter((l) => l !== ''),
        enableCaptions,
        enableTranslation,
        enableDubbing,
      });
      setName('');
      setLanguages('');
      setEnableCaptions(true);
      setEnableTranslation(true);
      setEnableDubbing(false);
      setRooms([...rooms, res.data.room]);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to create room');
    }
  };

  const handleJoin = (roomId) => {
    router.push(`/meeting/${roomId}`);
  };

  return (
    <Layout>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <h2 className="text-2xl font-bold mb-4">Your Rooms</h2>
          {rooms.length === 0 && <p>No rooms yet. Create one!</p>}
          <ul className="space-y-2">
            {rooms.map((room) => (
              <li
                key={room._id}
                className="border bg-white rounded p-3 flex justify-between items-center"
              >
                <div>
                  <h3 className="font-semibold">{room.name}</h3>
                  <p className="text-sm text-gray-600">
                    {room.languages?.length > 0
                      ? `Languages: ${room.languages.join(', ')}`
                      : 'No language restrictions'}
                  </p>
                </div>
                <button
                  onClick={() => handleJoin(room._id)}
                  className="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded"
                >
                  Join
                </button>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h2 className="text-2xl font-bold mb-4">Create Room</h2>
          {error && <div className="mb-3 text-red-600">{error}</div>}
          <form onSubmit={handleCreate} className="space-y-4 bg-white border rounded p-4">
            <div>
              <label className="block mb-1">Room Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full border rounded px-3 py-2"
                required
              />
            </div>
            <div>
              <label className="block mb-1">Allowed Languages (comma separated ISO codes)</label>
              <input
                type="text"
                value={languages}
                onChange={(e) => setLanguages(e.target.value)}
                className="w-full border rounded px-3 py-2"
                placeholder="e.g. en,es,fr"
              />
            </div>
            <div className="flex items-center space-x-3">
              <label className="flex items-center space-x-1">
                <input
                  type="checkbox"
                  checked={enableCaptions}
                  onChange={(e) => setEnableCaptions(e.target.checked)}
                />
                <span>Enable Captions</span>
              </label>
              <label className="flex items-center space-x-1">
                <input
                  type="checkbox"
                  checked={enableTranslation}
                  onChange={(e) => setEnableTranslation(e.target.checked)}
                />
                <span>Enable Translation</span>
              </label>
              <label className="flex items-center space-x-1">
                <input
                  type="checkbox"
                  checked={enableDubbing}
                  onChange={(e) => setEnableDubbing(e.target.checked)}
                />
                <span>Enable Dubbing</span>
              </label>
            </div>
            <button
              type="submit"
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded"
            >
              Create
            </button>
          </form>
        </div>
      </div>
    </Layout>
  );
}