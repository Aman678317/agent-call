import Link from 'next/link';
import Layout from '../components/Layout';
import { useContext } from 'react';
import { AuthContext } from '../contexts/AuthContext';

export default function Home() {
  const { user } = useContext(AuthContext);
  return (
    <Layout>
      <div className="max-w-2xl mx-auto text-center py-16">
        <h1 className="text-4xl font-bold mb-4">Real‑Time Multilingual Video Calls</h1>
        <p className="text-lg text-gray-700 mb-8">
          Connect with anyone around the world in your own language. Our platform
          offers live captions, instant translation and optional voice dubbing for
          seamless communication.
        </p>
        {user ? (
          <Link href="/dashboard">
            <button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded text-lg">
              Go to Dashboard
            </button>
          </Link>
        ) : (
          <div className="space-x-4">
            <Link href="/register">
              <button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded text-lg">
                Get Started
              </button>
            </Link>
            <Link href="/login" className="text-blue-600 hover:underline">
              Log In
            </Link>
          </div>
        )}
      </div>
    </Layout>
  );
}