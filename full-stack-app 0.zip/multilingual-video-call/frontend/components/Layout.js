import Link from 'next/link';
import { useContext } from 'react';
import { AuthContext } from '../contexts/AuthContext';

/**
 * Simple layout component that provides a top navigation bar and wraps
 * page content. If the user is authenticated, their name is displayed
 * and a logout link is provided. Otherwise, login and register links
 * are shown.
 */
export default function Layout({ children }) {
  const { user, logout } = useContext(AuthContext);
  return (
    <div className="flex flex-col min-h-screen">
      <nav className="bg-gray-900 text-white p-4 flex justify-between items-center">
        <div className="flex items-center space-x-4">
          <Link href="/">
            <span className="font-bold text-xl cursor-pointer">Multilingual VC</span>
          </Link>
          {user && (
            <>
              <Link href="/dashboard" className="hover:underline">
                Dashboard
              </Link>
              <Link href="/features" className="hover:underline">
                Features
              </Link>
            </>
          )}
        </div>
        <div>
          {user ? (
            <div className="flex items-center space-x-4">
              <span>{user.name}</span>
              <button
                onClick={logout}
                className="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded"
              >
                Logout
              </button>
            </div>
          ) : (
            <div className="flex items-center space-x-4">
              <Link href="/login" className="hover:underline">
                Login
              </Link>
              <Link href="/register" className="hover:underline">
                Register
              </Link>
            </div>
          )}
        </div>
      </nav>
      <main className="flex-1 bg-gray-100 p-4">{children}</main>
      <footer className="bg-gray-900 text-white p-4 text-center">
        &copy; {new Date().getFullYear()} Multilingual Video Calling Platform
      </footer>
    </div>
  );
}