import { useEffect, useRef } from 'react';

/**
 * Custom hook to simplify usage of the Web Speech API's SpeechRecognition.
 * It instantiates a recognizer, configures it for continuous listening,
 * optionally sets the recognition language, and exposes start and stop
 * methods. Partial and final results are delivered via callbacks.
 *
 * Browsers that do not support the API will log a warning and provide
 * no‑op start/stop methods.
 *
 * @param {Object} options
 * @param {string} options.lang The language code of the speaker (e.g. 'en').
 * @param {(result: { text: string, final: boolean }) => void} options.onResult Callback for partial and final results.
 */
export default function useSpeechRecognition({ lang, onResult }) {
  const recognitionRef = useRef(null);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const SpeechRecognition =
      window.SpeechRecognition || window.webkitSpeechRecognition || null;
    if (!SpeechRecognition) {
      console.warn('SpeechRecognition API not available in this browser');
      return;
    }
    const recognition = new SpeechRecognition();
    recognitionRef.current = recognition;
    recognition.lang = lang || 'en-US';
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.maxAlternatives = 1;

    recognition.onresult = (event) => {
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;
        const isFinal = event.results[i].isFinal;
        if (onResult) {
          onResult({ text: transcript, final: isFinal });
        }
      }
    };
    recognition.onerror = (event) => {
      console.error('Speech recognition error:', event.error);
    };
    return () => {
      recognition.stop();
    };
  }, [lang, onResult]);

  const start = () => {
    if (!recognitionRef.current) return;
    try {
      recognitionRef.current.start();
    } catch (err) {
      // Chrome may throw if start is called twice
    }
  };

  const stop = () => {
    if (recognitionRef.current) recognitionRef.current.stop();
  };

  return { start, stop };
}